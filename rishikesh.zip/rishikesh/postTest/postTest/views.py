# -*- coding: utf-8 -*-
"""
Created on Thu Sep 19 02:29:32 2019

@author: admin
"""

from django.http import JsonResponse, Http404 
import json
import datetime

def json1(request):
    if request.method.upper()=='GET':
        query = request.GET
        currentdate = datetime.datetime.now()       
        res={}
        for e in range(5):
            currentdate += datetime.timedelta(days=1)
            res[currentdate.strftime("%d/%m/%Y")] = dict(text=query['location'],high='36',low='29')
        return JsonResponse(res)
       
    else:
        raise Http404("this is rest api only support GET")     