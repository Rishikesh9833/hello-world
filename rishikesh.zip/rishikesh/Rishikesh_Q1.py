import pandas as pd
iris = pd.read_csv("data/iris.csv")
ud = set()
for e in iris.Name:
    ud.add(e)
print(ud)
print(iris.groupby('Name').agg({'SepalLength':'max','SepalWidth':'min'}))